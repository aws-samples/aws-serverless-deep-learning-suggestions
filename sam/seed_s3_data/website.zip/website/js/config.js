/*
 * Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
 * SPDX-License-Identifier: MIT-0
 */
let awsConfigOptions = {
    identity_pool_id: "REPLACE_ME_IDENTITY_POOL_ID",
    unique_suffix: "REPLACE_ME_UNIQUE_SUFFIX",
    api_base_url: "REPLACE_ME_API_BASE_URL" // Omit trailing slash
}
